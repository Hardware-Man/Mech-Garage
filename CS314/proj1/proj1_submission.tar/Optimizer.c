/*
 *********************************************
 *  314 Principles of Programming Languages  *
 *  Spring 2014                              *
 *  Authors: Ulrich Kremer                   *
 *           Hans Christian Woithe           *
 *********************************************
 */

#include <assert.h>
#include <stdio.h>
#include <stdlib.h>
#include "InstrUtils.h"
#include "Utils.h"

Instruction* find_critical(int, Instruction*);
Instruction* find_critical_load(int, int, Instruction*);
Instruction* find_more_critical(int, Instruction*);

Instruction* find_critical(int write_id, Instruction *root)
{
	Instruction *ptr, *ptr_store_curr, *ptr_store_last;
	ptr = root;
	ptr_store_curr = ptr_store_last = NULL;
	while (ptr) {
		if (ptr->opcode == WRITE && ptr->field1 == write_id) {
			ptr_store_curr = ptr_store_last;
			if (ptr_store_curr) {
				ptr_store_curr->critical = '1';
				root = find_more_critical(ptr_store_curr->field2, root);
			}
		}
		if (ptr->opcode == STORE && ptr->field1 == write_id && ptr->critical != '1') {
			ptr_store_last = ptr;
		}
		ptr = ptr->next;
	}
	return root;
}

Instruction* find_critical_load(int load_reg, int load_id, Instruction *root)
{
	Instruction *ptr, *ptr_store_curr, *ptr_store_last;
	ptr = root;
	ptr_store_curr = ptr_store_last = NULL;
	while (ptr) {
		if (ptr->opcode == LOAD && ptr->field1 == load_reg) {
			ptr_store_curr = ptr_store_last;
			break;
		}
		if (ptr->opcode == STORE && ptr->field1 == load_id && ptr->critical != '1') {
			ptr_store_last = ptr;
		}
		ptr = ptr->next;
	}
	if (ptr_store_curr) {
		ptr_store_curr->critical = '1';
		root = find_more_critical(ptr_store_curr->field2, root);
	}
	return root;
}

Instruction* find_more_critical(int reg, Instruction *root)
{
	Instruction *ptr;
	ptr = root;
	while (ptr) {
		switch (ptr->opcode) {
			case LOAD:
				if (ptr->field1 == reg && ptr->critical != '1') {
					ptr->critical = '1';
					root = find_more_critical(ptr->field1, root);
					root = find_critical_load(ptr->field1, ptr->field2, root);
				}
				break;
			case LOADI:
				if (ptr->field1 == reg && ptr->critical != '1') {
					ptr->critical = '1';
					root = find_more_critical(ptr->field1, root);
				}
				break;
			case ADD:
			case SUB:
			case MUL:
			case AND:
			case OR:
				if (ptr->field1 == reg && ptr->critical != '1') {
					ptr->critical = '1';
					root = find_more_critical(ptr->field1, root);
					root = find_more_critical(ptr->field2, root);
					root = find_more_critical(ptr->field3, root);
				}
			default:
				break;
		}
		ptr = ptr->next;
	}
	return root;
}

int main()
{
	Instruction *head;


	head = ReadInstructionList(stdin);
	if (!head) {
		WARNING("No instructions\n");
		exit(EXIT_FAILURE);
	}

	Instruction *ptr, *write_list, *write_list_tail;

	ptr = head;
	write_list = write_list_tail = NULL;
	while (ptr) {
		ptr->critical = '0';
		switch (ptr->opcode) {
			case WRITE:
				if (!write_list) {
					write_list = write_list_tail = (Instruction *) calloc(1, sizeof(Instruction));
					write_list->field1 = write_list_tail->field1 = ptr->field1;
					write_list->next = write_list_tail->next = NULL;
					write_list->prev = write_list_tail->prev = NULL;
				}
				else {
					Instruction *temp = (Instruction *) calloc(1, sizeof(Instruction));
					temp->field1 = ptr->field1;
					temp->next = NULL;
					temp->prev = write_list_tail;
					write_list_tail->next = temp;
					write_list_tail = temp;
				}
			case READ:
				ptr->critical = '1';
			default:
				ptr = ptr->next;
		}
	}

	while (write_list) {
		head = find_critical(write_list->field1, head);
		write_list = write_list->next;
	}
	DestroyInstructionList(write_list);

	ptr = head;
	while (ptr) {
		if (ptr->critical != '1') {
			if (ptr->prev) {
				Instruction *prevtemp = ptr->prev;
				prevtemp->next = ptr->next;
			}
			Instruction *temp = ptr;
			ptr = ptr->next;
			if (ptr) {
				ptr->prev = temp->prev;
			}
			if (temp == head) {
				head = ptr;
			}
			free(temp);
		}
		else {
			ptr = ptr->next;
		}
	}

	if (head) {
		PrintInstructionList(stdout, head);
		DestroyInstructionList(head);
	}
	return EXIT_SUCCESS;
}